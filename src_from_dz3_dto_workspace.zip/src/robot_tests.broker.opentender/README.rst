robot_tests.broker.opentender
=============================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.opentender|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.opentender| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.opentender.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.opentender
