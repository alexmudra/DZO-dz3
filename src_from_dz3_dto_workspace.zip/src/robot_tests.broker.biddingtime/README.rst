robot_tests.broker.biddingtime
=======================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.biddingtime|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.biddingtime| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.biddingtime.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.biddingtime
