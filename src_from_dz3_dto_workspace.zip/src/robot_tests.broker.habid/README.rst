robot_tests.broker.habid
========================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.habid|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.habid| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.habid.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.habid
