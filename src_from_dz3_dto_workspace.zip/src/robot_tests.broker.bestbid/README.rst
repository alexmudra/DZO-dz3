robot_tests.broker.bestbid
==========================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.bestbid|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.bestbid| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.bestbid.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.bestbid
