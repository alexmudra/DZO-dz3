robot_tests.broker.tsbgalcontract
===========================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.tsbgalcontract|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.tsbgalcontract| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.tsbgalcontract.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.tsbgalcontract
