robot_tests.broker.privatmarket
===============================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.privatmarket|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.privatmarket| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.privatmarket.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.privatmarket

Бранч корневого проекта `Robot tests <https://github.com/openprocurement/robot_tests>`__ - **eauction_cdb2**

Бранч площадки `PrivatMarket <https://github.com/openprocurement/robot_tests.broker.privatmarket>`__ - **eauction_cdb2**

Информация по Robot тестам для системы электронных аукционов ProZorro.Sale на `Wiki <https://github.com/openprocurement/robot_tests/wiki/ProZorro.Sale>`__
