robot_tests.broker.polonex
==========================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.polonex|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.polonex| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.polonex.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.polonex
