robot_tests.broker.newtend
==========================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.newtend|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.newtend| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.newtend.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.newtend
