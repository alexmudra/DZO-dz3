robot_tests.broker.sets
=======================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.sets|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.sets| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.sets.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.sets
