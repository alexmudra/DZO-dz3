robot_tests.broker.25h8
=======================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.25h8|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.25h8| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.25h8.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.25h8
