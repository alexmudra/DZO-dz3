robot_tests.broker.podilska
===========================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.podilska|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.podilska| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.podilska.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.podilska
