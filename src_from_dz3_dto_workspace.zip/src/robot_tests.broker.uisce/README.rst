robot_tests.broker.uisce
===========================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.uisce|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.uisce| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.uisce.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.uisce
