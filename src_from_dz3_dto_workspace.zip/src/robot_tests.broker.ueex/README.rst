robot_tests.broker.ueex
=======================

|Join the chat at
https://gitter.im/openprocurement/robot_tests.broker.ueex|

This repository is a part of OpenProcurement `Robot
tests <https://github.com/openprocurement/robot_tests>`__ package.

.. |Join the chat at https://gitter.im/openprocurement/robot_tests.broker.ueex| image:: https://badges.gitter.im/openprocurement/robot_tests.broker.ueex.svg
   :target: https://gitter.im/openprocurement/robot_tests.broker.ueex
